/**
 *  Duma Andrei Dorian
 *  315 CA
 */
#include <stdio.h>
#include "algorithm.h"

int main()
{
	Algorithm homework;
	homework.resolve();
	return 0;
}

