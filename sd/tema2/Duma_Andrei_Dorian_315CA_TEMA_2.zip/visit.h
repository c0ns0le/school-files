/**
  *    Duma Andrei Dorian
  *    315 CA
  */

#ifndef __VISIT_H
#define __VISIT_H

class Visit {
    public:
        char url[100];
        int date;

        Visit();
        Visit(char* url, int date);
};

#endif
