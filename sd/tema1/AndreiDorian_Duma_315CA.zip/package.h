/*\
 *   Duma Andrei Dorian
 *   315 CA
\*/

#ifndef __PACKAGE_H
#define __PACKAGE_H


struct Package {
    int personal_id;
    int package_weight;
};

#endif
