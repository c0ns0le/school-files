#include <stdio.h>
#include <stdlib.h>

#include "invertedindex.h"

int main() {
	solve();
	
	return 0;
}
